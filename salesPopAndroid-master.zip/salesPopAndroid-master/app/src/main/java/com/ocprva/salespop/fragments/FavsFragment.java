package com.ocprva.salespop.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ocprva.salespop.R;
import com.ocprva.salespop.activities.FailureActivity;
import com.ocprva.salespop.adapters.ProductAdapter;
import com.ocprva.salespop.adapters.ValoracionAdapter;
import com.ocprva.salespop.api.pojo.Product;
import com.ocprva.salespop.api.pojo.ProductServiceInterfaz;
import com.ocprva.salespop.api.pojo.Usuario;
import com.ocprva.salespop.api.pojo.Valoracion;
import com.ocprva.salespop.api.pojo.ValoracionServiceInterfaz;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FavsFragment extends Fragment {

    private Usuario usuario;
    private RecyclerView recyclerFavs;
    private ValoracionAdapter vAdapter;
    public static ArrayList<Valoracion> listaValoraciones;

    public FavsFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static FavsFragment newInstance(Usuario user) {
        FavsFragment fragment = new FavsFragment();
        Bundle args = new Bundle();
        args.putSerializable("user", user);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_favs, container, false);

        usuario = (Usuario) getArguments().getSerializable("user");

        recyclerFavs = view.findViewById(R.id.recyclerFavs);

        recyclerFavs.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerFavs.setLayoutManager(layoutManager);

        System.out.println("home");

        vAdapter = new ValoracionAdapter(listaValoraciones);

        Retrofit retrofit = new Retrofit.Builder().baseUrl("http://192.168.8.102:8080/api/").addConverterFactory(GsonConverterFactory.create()).build();

        ValoracionServiceInterfaz valoracionService = retrofit.create(ValoracionServiceInterfaz.class);
        listaValoraciones = new ArrayList<>();
        Call<ArrayList<Valoracion>> call = valoracionService.getValoraciones();

        call.enqueue(new Callback<ArrayList<Valoracion>>() {
            @Override
            public void onResponse(Call<ArrayList<Valoracion>> call, Response<ArrayList<Valoracion>> response) {
                System.out.println("funcionaAAAAAAAAAAA");
                for (Valoracion valoracion: response.body()) {
                    if (valoracion.getUsuario().getMail().equals(usuario.getMail())){
                        listaValoraciones.add(valoracion);
                    }
                }
                vAdapter.setData(listaValoraciones);
                recyclerFavs.setAdapter(vAdapter);
            }

            @Override
            public void onFailure(Call<ArrayList<Valoracion>> call, Throwable t) {

            }
        });

        /*ProductServiceInterfaz service = retrofit.create(ProductServiceInterfaz.class);
        listaValoraciones = new ArrayList<>();
        Call<ArrayList<Product>> call = service.getProducts();

        call.enqueue(new Callback<ArrayList<Product>>() {
            @Override
            public void onResponse(Call<ArrayList<Product>> call, Response<ArrayList<Product>> response) {
                System.out.println("funcionaAAAAAAAAAAA");
                listaValoraciones = response.body();
                vAdapter.setData(listaValoraciones);
                recyclerFavs.setAdapter(vAdapter);

            }

            @Override
            public void onFailure(Call<ArrayList<Product>> call, Throwable t) {
                Intent intent = new Intent(getActivity(), FailureActivity.class);
                System.out.println("POR QUEEEEEEEEEEEEEEEEEEEEEEE");
                startActivity(intent);
            }
        });*/

        return view;
    }
}