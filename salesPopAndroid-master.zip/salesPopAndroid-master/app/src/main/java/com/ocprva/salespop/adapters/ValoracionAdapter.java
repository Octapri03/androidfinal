package com.ocprva.salespop.adapters;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ocprva.salespop.R;
import com.ocprva.salespop.api.pojo.Foto;
import com.ocprva.salespop.api.pojo.FotoServiceInterfaz;
import com.ocprva.salespop.api.pojo.Product;
import com.ocprva.salespop.api.pojo.Valoracion;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ValoracionAdapter extends RecyclerView.Adapter<ValoracionAdapter.ViewHolderDatos> implements View.OnClickListener{

    ArrayList<Valoracion> listaValoraciones;

    private View.OnClickListener listener;

    public ValoracionAdapter(ArrayList<Valoracion> listaValoraciones) {
        this.listaValoraciones = listaValoraciones;
    }

    @NonNull
    @Override
    public ValoracionAdapter.ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_valoracion, null, false);
// Para que cada ítem ocupe el match_parent
        RecyclerView.LayoutParams lp =
                new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(lp);

        view.setOnClickListener(this);

        return new ViewHolderDatos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ValoracionAdapter.ViewHolderDatos holder, int position) {
        holder.asignarDatos(listaValoraciones.get(position));
    }

    @Override
    public int getItemCount() {
        return listaValoraciones.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    @Override
    public void onClick(View view) {
        if (listener!=null){
            listener.onClick(view);
        }
    }

    public void setData(ArrayList<Valoracion> data) {
        this.listaValoraciones = data;
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {
        TextView nameValoracion, puntuacionValoracion;
        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            this.nameValoracion = itemView.findViewById(R.id.nameValoracion);
            this.puntuacionValoracion = itemView.findViewById(R.id.puntuacionValoracion);
        }

        public void asignarDatos(Valoracion valoracion){
            nameValoracion.setText(valoracion.getName());
            puntuacionValoracion.setText(valoracion.getPuntuacion() + " Estrellas");
            }
    }
}