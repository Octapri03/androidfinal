package com.ocprva.salespop.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ocprva.salespop.R;
import com.ocprva.salespop.api.pojo.Categoria;
import com.ocprva.salespop.api.pojo.Usuario;
import com.ocprva.salespop.api.pojo.UsuarioServiceInterfaz;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class SignUpActivity extends AppCompatActivity {

    EditText etNombreRegistro, etUsernameRegistro, etMailRegistro, etPwdRegistro, etTelefRegistro;
    Button btnSignUpRegistro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etNombreRegistro = findViewById(R.id.etNombreRegistro);
        etUsernameRegistro = findViewById(R.id.etUsernameRegistro);
        etMailRegistro = findViewById(R.id.etMailRegistro);
        etPwdRegistro = findViewById(R.id.etPwdRegistro);
        etTelefRegistro = findViewById(R.id.etTelefRegistro);

        btnSignUpRegistro = findViewById(R.id.btnSignUpRegistro);

        btnSignUpRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!etNombreRegistro.getText().toString().equals("") && !etUsernameRegistro.getText().toString().equals("") && !etMailRegistro.getText().toString().equals("") && !etPwdRegistro.getText().toString().equals("") && !etTelefRegistro.getText().toString().equals("") ){

                    Retrofit retrofit = new Retrofit.Builder().baseUrl("http://192.168.8.102:8080/api/").addConverterFactory(GsonConverterFactory.create()).build();
                    UsuarioServiceInterfaz userService = retrofit.create(UsuarioServiceInterfaz.class);

                    Usuario user = new Usuario();
                    user.setMail(etMailRegistro.getText().toString());
                    user.setName(etNombreRegistro.getText().toString());
                    user.setUserName(etUsernameRegistro.getText().toString());
                    user.setPassword(etPwdRegistro.getText().toString());
                    user.setNumTel(etTelefRegistro.getText().toString());
                    user.setOnSale(new ArrayList<>());
                    Call<Usuario> call = userService.addUser(user);
                    call.enqueue(new Callback<Usuario>() {
                        @Override
                        public void onResponse(Call<Usuario> call, Response<Usuario> response) {
                            System.out.println(response.isSuccessful());

                            Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                        }

                        @Override
                        public void onFailure(Call<Usuario> call, Throwable t) {

                        }
                    });

                }
                else Toast.makeText(SignUpActivity.this, "rellene los campos", Toast.LENGTH_SHORT).show();
            }
        });
    }

}